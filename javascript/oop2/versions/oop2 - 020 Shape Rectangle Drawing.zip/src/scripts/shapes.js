function hello() {
    return "Hello";
}

class Shape {
    constructor(x,y) {
        this.x = x;
        this.y = y;
    }
}

class Rectangle extends Shape {

}

class Drawing {
    constructor(xxxwidth, height) {
        this.width = xxxwidth;
        this.height = height;
        this.shapes = {};
        this.counter = 1;
    }
    nextKey() {
        return `k${this.counter++}`;
    }
    createRectangle(x,y) {
        const key = this.nextKey();
        const rect = new Rectangle(x,y);
        this.shapes[key] = rect;
        return key;
    }
    getShape(theKey) {
        return this.shapes[theKey];
    }
}

export default {hello, Shape, Rectangle, Drawing};
