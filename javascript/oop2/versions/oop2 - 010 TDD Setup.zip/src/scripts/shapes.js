function hello() {
    return "Hello";
}

export default {hello};
