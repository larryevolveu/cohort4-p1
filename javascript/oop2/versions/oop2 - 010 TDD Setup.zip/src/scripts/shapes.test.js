//
// npm test shapes -- -t plumb
//
import shapes from './shapes'

test('test plumbing', () => {
    expect(shapes.hello()).toBe("Hello");
});   